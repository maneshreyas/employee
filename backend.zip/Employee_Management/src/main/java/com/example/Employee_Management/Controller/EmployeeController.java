package com.example.Employee_Management.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.Employee_Management.Repository.EmployeeRepository;
import com.example.Employee_Management.model.Employee;

@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "http://localhost:56325")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    // ✅ Get all employees
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return ResponseEntity.ok(employees);
    }

    // ✅ Add a new employee
    @PostMapping
    public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
        employeeRepository.save(employee);
        return ResponseEntity.ok("Employee added successfully");
    }

    // ✅ Delete employee by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable Long id) {
        if (!employeeRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        employeeRepository.deleteById(id);
        return ResponseEntity.ok("Deleted successfully");
    }

    // ✅ Update employee by ID
    @PutMapping("/{id}")
    public ResponseEntity<String> updateEmployee(@PathVariable Long id, @RequestBody Employee updatedEmployee) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Employee employee = optionalEmployee.get();
        employee.setMessId(updatedEmployee.getMessId());
        employee.setName(updatedEmployee.getName());
        employee.setRoomNo(updatedEmployee.getRoomNo());
        employeeRepository.save(employee);
        return ResponseEntity.ok("Updated successfully");
    }

    // ✅ Get employee by ID
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        Optional<Employee> employee = employeeRepository.findById(id);
        return employee.map(ResponseEntity::ok)
                       .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
