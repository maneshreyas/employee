import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Labour } from '../model/labour';

@Injectable({
  providedIn: 'root'
})
export class LabourserviceService {

  private baseUrl = 'http://localhost:1515/labour';

  constructor(private http: HttpClient) {}

  /* ---------- CRUD ---------- */

  /** GET all */
  getAllLabours(): Observable<Labour[]> {
    return this.http.get<Labour[]>(`${this.baseUrl}/getlab`);
  }

  /** POST create */
  createLabour(labour: Labour): Observable<string> {
    return this.http.post<string>(
      `${this.baseUrl}/addlabour`,
      labour,
      { responseType: 'text' as 'json' }
    );
  }

  /** GET one */
  getLabourById(id: number): Observable<Labour> {
    return this.http.get<Labour>(`${this.baseUrl}/findlab/${id}`);
  }

  /** PUT update */
  updateLabour(id: number, labour: Labour): Observable<string> {
    return this.http.put<string>(
      `${this.baseUrl}/update/${id}`,
      labour,
      { responseType: 'text' as 'json' }
    );
  }

  /** DELETE */
  deleteLabour(id: number): Observable<string> {
    return this.http.delete<string>(
      `${this.baseUrl}/dellab/${id}`,
      { responseType: 'text' as 'json' }
    );
  }
}
