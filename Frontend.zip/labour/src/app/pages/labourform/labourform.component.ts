import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { LabourserviceService } from '../../service/labourservice.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Labour } from '../../model/labour';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-labourform',
  standalone: true,
  imports: [RouterModule, CommonModule, ReactiveFormsModule],
  templateUrl: './labourform.component.html',
  styleUrls: ['./labourform.component.css']
})
export class LabourformComponent implements OnInit {
  form!: FormGroup;
  id?: number;

  constructor(
    private labourservice: LabourserviceService,
    private router: Router,
    private route: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    // Create form group with validation
    this.form = this.fb.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      salary: ['', [Validators.required, Validators.pattern('^[0-9]+$')]]
    });

    // Check for edit mode
    this.route.paramMap.subscribe(params => {
      const idParam = params.get('id');
      if (idParam) {
        this.id = +idParam;
        this.labourservice.getLabourById(this.id).subscribe((data: Labour) => {
          this.form.patchValue(data);
        });
      }
    });
  }

  onSubmit(): void {
    if (this.form.invalid) {
      alert('Please fill all required fields correctly.');
      return;
    }

    const labour: Labour = this.form.value;

    if (this.id) {
      // Update mode
      this.labourservice.updateLabour(this.id, labour).subscribe(() => {
        alert('Labour updated successfully!');
        this.router.navigate(['/labourlist']);
      }, err => {
        console.error('Update error:', err);
        alert('Failed to update labour');
      });
    } else {
      // Create mode
      this.labourservice.createLabour(labour).subscribe(() => {
        alert('Labour created successfully!');
        this.router.navigate(['/labourlist']);
      }, (err: any) => {
        console.error('Create error:', err);
        alert('Failed to create labour');
      });
    }
  }
}
