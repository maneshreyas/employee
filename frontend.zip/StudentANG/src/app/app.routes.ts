import { Routes } from '@angular/router';
import { StudentFormComponent } from './pages/student-form/student-form.component';
import { StudentListComponent } from './pages/student-list/student-list.component';

export const routes: Routes = [
   {path:'',component:StudentListComponent},
   
   {path:'student-form',component:StudentFormComponent},
   {path:'edit/:id',component:StudentFormComponent},
   {
  path: 'student-form/:id',
  loadComponent: () => import('./pages/student-form/student-form.component').then(m => m.StudentFormComponent)
}

];
