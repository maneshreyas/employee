import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { StudentListComponent } from "./pages/student-list/student-list.component";
import { StudentFormComponent } from "./pages/student-form/student-form.component";

@Component({
  selector: 'app-root',
  imports: [RouterModule, CommonModule, RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'StudentANG';
}
