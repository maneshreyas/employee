import { Component, OnInit } from '@angular/core';
import { StudentsService } from '../../service/students.service';
import { Students } from '../../models/students';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {

  students: Students[] = [];

  constructor(
    private studentsService: StudentsService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getStudents();
  }

  getStudents(): void {
    this.studentsService.getAllStudents().subscribe({
      next: (data) => {
        this.students = data;
      },
      error: (err) => {
        console.error('Error fetching students:', err);
      }
    });
  }

  addStudent(): void {
    this.router.navigate(['student-form']);
  }

  editStudent(id: number): void {
  this.router.navigate([`/student-form/${id}`]);  // must match your route path
}

  deleteStudent(id: number): void {
    if (confirm('Are you sure you want to delete this employee?')) {
      this.studentsService.deleteStudent(id).subscribe({
        next: () => this.getStudents(),
        error: (err) => console.error('Delete failed:', err)
      });
    }
  }
}
