import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { StudentsService } from '../../service/students.service';
import { Students } from '../../models/students';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-student-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent implements OnInit {
  form!: FormGroup;
  id: number | null = null;

  constructor(
    public fb: FormBuilder,
    public studentsService: StudentsService,
    public route: ActivatedRoute,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      name: ['', Validators.required],
      roomNo: ['', Validators.required],
      messId: ['', Validators.required]
    });

    this.route.paramMap.subscribe(params => {
      const idParam = params.get('id');
      if (idParam) {
        this.id = +idParam;
        this.studentsService.getStudentById(this.id).subscribe((student: Students) => {
          this.form.patchValue(student);
        });
      }
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    const student: Students = this.form.value;

    if (this.id) {
      this.studentsService.updateStudent(this.id, student).subscribe(() => {
        alert('Employee updated successfully!');
        this.router.navigate(['/']);
      });
    } else {
      this.studentsService.createStudent(student).subscribe(() => {
        alert('Employee added successfully!');
        this.router.navigate(['/']);
      });
    }
  }
}
