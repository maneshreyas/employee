export interface Labour {
  id?: number;
  name: string;
  address: string;
  salary: number;
}
