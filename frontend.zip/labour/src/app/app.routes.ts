import { Routes } from '@angular/router';
import { LabourformComponent } from './pages/labourform/labourform.component';
import { LabourlistComponent } from './pages/labourlist/labourlist.component';

export const routes: Routes = [
    {path : '', component: LabourlistComponent},
    {path : 'labourform', component: LabourformComponent},
    { path: 'edit/:id', component: LabourformComponent }
    
];
    