package com.example.labour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabourApplicationTests {

	@Test
	void contextLoads() {
	}

}
